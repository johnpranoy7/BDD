package com.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class EmployeeDetails {
	@FindBy(how=How.ID,id="txtFirstName")
	WebElement firstName;
	@FindBy(how=How.ID,id="txtLastName")
	WebElement lastName;
	@FindBy(how=How.ID,id="txtEmail")
	WebElement email;
	@FindBy(how=How.ID,id="txtPhone")
	WebElement contact;
	@FindBy(how=How.NAME,name="address1")
	WebElement line1;
	@FindBy(how=How.NAME,name="address2")
	WebElement line2;
	@FindBy(how=How.NAME,name="city")
	WebElement city;
	@FindBy(how=How.NAME,name="state")
	WebElement state;
	@FindBy(how=How.XPATH,xpath="/html/body/form/table/tbody/tr[11]/td/a")
	WebElement link;
	
	public void setFirstName(String firstNam) {
		this.firstName.sendKeys(firstNam);
	}
	public void setLastName(String lastNam) {
		this.lastName.sendKeys(lastNam);
	}
	public void setEmail(String emai) {
		this.email.clear();
		this.email.sendKeys(emai);
	}
	public void setContact(String contac) {
		this.contact.clear();
		this.contact.sendKeys(contac);
	}
	public void setLine1(String lin1) {
		this.line1.sendKeys(lin1);
	}
	public void setLine2(String lin2) {
		this.line2.sendKeys(lin2);
	}
	public void setCity(String cit) {
		this.city.sendKeys(cit);
	}
	public void setState(String stat) {
		this.state.sendKeys(stat);
	}
	
	public void onClick()
	{
		this.link.click();
	}
	
}
