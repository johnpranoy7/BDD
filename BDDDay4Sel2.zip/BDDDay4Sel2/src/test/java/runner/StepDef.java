package runner;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.beans.EmployeeDetails;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	WebDriver driver;
	EmployeeDetails emp;
	String title=null;
	@Before
	public void init()
	{
		System.setProperty("webdriver.chrome.driver","MyDriver\\chromedriver1.exe");
		driver= new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.manage().window().maximize();
		emp= new EmployeeDetails();
		PageFactory.initElements(driver, emp);
	}
	
	@After
	public void closer() throws Exception
	{
		Thread.sleep(5000);
		driver.quit();
	}
	
	@Given("^Employee page$")
	public void employee_page() throws Throwable {
		driver.get("file:///C:/Users/JPRANOYY/Desktop/New%20Workspace/BDDDay4Sel2/webpage/Employee%20Details.html");
	}

	@When("^check title for employee page$")
	public void check_title_for_employee_page() throws Throwable {
		 title= driver.getTitle();
	}

	@Then("^validate title$")
	public void validate_title() throws Throwable {
		String expected="Employee Details";
		String actual=title;
		assertEquals(expected, actual);
	}

	@When("^firstName is empty$")
	public void firstname_is_empty() throws Throwable {
		emp.onClick();
		Thread.sleep(500);
	}

	@Then("^alert'Please fill the First Name'$")
	public void alert_Please_fill_the_First_Name() throws Throwable {
		String expected="Please fill the First Name";
		String actual=driver.switchTo().alert().getText();
		assertEquals(expected, actual);
	}

	@When("^lastname is empty$")
	public void lastname_is_empty() throws Throwable {
		 driver.switchTo().alert().dismiss();
		emp.setFirstName("John");
	   emp.onClick();
	   Thread.sleep(500);
	}

	@Then("^alert'Please fill the Last Name'$")
	public void alert_Please_fill_the_Last_Name() throws Throwable {
	    String expected="Please fill the Last Name";
	    String actual=driver.switchTo().alert().getText();
	    assertEquals(expected, actual);
	}

	@When("^email is empty$")
	public void email_is_empty() throws Throwable {
		 driver.switchTo().alert().dismiss();
		emp.setLastName("Pranoy");
	    emp.onClick();
	    Thread.sleep(500);
	}

	@Then("^alert'Please fill the Email'$")
	public void alert_Please_fill_the_Email() throws Throwable {
	   String expected="Please fill the Email";
	   String actual=driver.switchTo().alert().getText();
	   assertEquals(expected, actual);
	}

	@When("^email is invalid$")
	public void email_is_invalid() throws Throwable {
		 driver.switchTo().alert().dismiss();
		emp.setEmail("aaa");
	    emp.onClick();
	    Thread.sleep(500);
	}

	@Then("^alert'Please enter valid Email Id\\.'$")
	public void alert_Please_enter_valid_Email_Id() throws Throwable {
	    String expected="Please enter valid Email Id.";
	    String actual=driver.switchTo().alert().getText();
	    assertEquals(expected, actual);
	}

	@When("^contact is empty$")
	public void contact_is_empty() throws Throwable {
		 driver.switchTo().alert().dismiss();
		emp.setEmail("johnpranoy7@gmail.com");
	    emp.onClick();
	    Thread.sleep(500);
	}

	@Then("^alert'Please fill the Contact No\\.'$")
	public void alert_Please_fill_the_Contact_No() throws Throwable {
		String expected="Please fill the Contact No.";
	    String actual=driver.switchTo().alert().getText();
	    assertEquals(expected, actual);
	}

	@When("^contact is invalid$")
	public void contact_is_invalid() throws Throwable {
		 driver.switchTo().alert().dismiss();
		emp.setContact("122");
	    emp.onClick();
	    Thread.sleep(500);
	}

	@Then("^alert'Please enter valid Contact no\\.'$")
	public void alert_Please_enter_valid_Contact_no() throws Throwable {
		String expected="Please enter valid Contact no.";
	    String actual=driver.switchTo().alert().getText();
	    assertEquals(expected, actual);
	}

	@When("^address line one is empty$")
	public void address_line_one_is_empty() throws Throwable {
		 driver.switchTo().alert().dismiss();
		emp.setContact("7894561234");
	    emp.onClick();
	    Thread.sleep(500);
	}

	@Then("^alert'Please fill the address line one'$")
	public void alert_Please_fill_the_address_line_one() throws Throwable {
		String expected="Please fill the address line 1";
	    String actual=driver.switchTo().alert().getText();
	    assertEquals(expected, actual);
	}

	@When("^address line two is empty$")
	public void address_line_two_is_empty() throws Throwable {
		driver.switchTo().alert().dismiss();
		emp.setLine1("A");
		emp.onClick();
		Thread.sleep(500);
	}

	@Then("^alert'Please fill the address line two'$")
	public void alert_Please_fill_the_address_line_two() throws Throwable {
		String expected="Please fill the address line 2";
	    String actual=driver.switchTo().alert().getText();
	    assertEquals(expected, actual);
	}
	
	@When("^city is empty$")
	public void city_is_empty() throws Throwable {
		 driver.switchTo().alert().dismiss();
		emp.setLine2("B");
	    emp.onClick();
	    Thread.sleep(500);
	}

	@Then("^alert'Please select city'$")
	public void alert_Please_select_city() throws Throwable {
		String expected="Please select city";
	    String actual=driver.switchTo().alert().getText();
	    assertEquals(expected, actual);
	}

	@When("^state is empty$")
	public void state_is_empty() throws Throwable {
		 driver.switchTo().alert().dismiss();
		emp.setCity("Hyderabad");
	    emp.onClick();
	    Thread.sleep(500);
	}

	@Then("^alert'Please select state'$")
	public void alert_Please_select_state() throws Throwable {
		String expected="Please select state";
	    String actual=driver.switchTo().alert().getText();
	    assertEquals(expected, actual);
	}

	@When("^Employee details are validated$")
	public void employee_details_are_validated() throws Throwable {
		 driver.switchTo().alert().dismiss(); 	
		emp.setState("Telangana");
		    emp.onClick();
		    Thread.sleep(500);
	}

	@Then("^alert'Personal details are validated and accepted successfully\\.' and redirect to next page$")
	public void alert_Personal_details_are_validated_and_accepted_successfully_and_redirect_to_next_page() throws Throwable {
		String expected="Personal details are validated and accepted successfully.";
	    String actual=driver.switchTo().alert().getText();
	    assertEquals(expected, actual);
	    System.out.println("Page1 validated");
	    
	}


	@Given("^Courses page$")
	public void courses_page() throws Throwable {
		driver.get("file:///C:/Users/JPRANOYY/Desktop/New%20Workspace/BDDDay4Sel2/webpage/CoursesToOpt.html");
	}

	@When("^graduation is empty$")
	public void graduation_is_empty() throws Throwable {
	  
	}

	@Then("^alert'Please Select Graduation'$")
	public void alert_Please_Select_Graduation() throws Throwable {
	    
	}

	@When("^percentage is empty$")
	public void percentage_is_empty() throws Throwable {
	    
	}

	@Then("^alert'Please fill Percentage detail'$")
	public void alert_Please_fill_Percentage_detail() throws Throwable {
	   
	}

	@When("^passing year is empty$")
	public void passing_year_is_empty() throws Throwable {
	  
	}

	@Then("^alert'Please fill Passing Year'$")
	public void alert_Please_fill_Passing_Year() throws Throwable {
	   
	}

	@When("^project name is empty$")
	public void project_name_is_empty() throws Throwable {
	    
	}

	@Then("^alert'Please fill Project Name'$")
	public void alert_Please_fill_Project_Name() throws Throwable {
	  
	}

	@When("^Project names are not selected$")
	public void project_names_are_not_selected() throws Throwable {
	   
	}

	@Then("^alert'Please Select Technologies Used'$")
	public void alert_Please_Select_Technologies_Used() throws Throwable {
	 
	}

	@When("^Other technologies are empty$")
	public void other_technologies_are_empty() throws Throwable {
	   
	}

	@Then("^alert'Please fill other Technologies Used'$")
	public void alert_Please_fill_other_Technologies_Used() throws Throwable {
	   
	}

	@Given("^on Courses page$")
	public void on_Courses_page() throws Throwable {
	  
	}

	@When("^course page details are validates$")
	public void course_page_details_are_validates() throws Throwable {
	   
	}

	@Then("^alert'Your Registration Has succesfully done Plz check you registerd email for account activation link !!!'$")
	public void alert_Your_Registration_Has_succesfully_done_Plz_check_you_registerd_email_for_account_activation_link() throws Throwable {
	    
	}
}
