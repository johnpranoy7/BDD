package runner;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.beans.HotelBooking;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	WebDriver driver;
	/*By firstName;
	By lastName;
	By email;
	By mobile;
	By button;
	By city;
	By state;
	By guest;
	By cardHolderName;
	By debitCardNumber;
	By cvv;
	By expMonth;
	By expYear;*/
	String title=null;
	 HotelBooking hotelbean;
	
	@Before
	public void init()
	{
		System.setProperty("webdriver.chrome.driver","driver\\chromedriver1.exe");
		driver= new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.manage().window().maximize();
		hotelbean=new HotelBooking();
		PageFactory.initElements(driver, hotelbean);
	}
	
	@After
	public void finish() throws Exception
	{
		Thread.sleep(5000);
		System.out.println("After");
		driver.quit();
	}
	
	@Given("^HotelBooking Form Page for validation$")
	public void hotelbooking_Form_Page_for_validation() throws Throwable {
	   driver.get("file:///C:/Users/JPRANOYY/Desktop/New%20Workspace/BDDDay4SeleniumValidation/webpage/hotelbooking.html");
	 
	   /* firstName=By.id("txtFirstName");
	   lastName=By.id("txtLastName");
	   email=By.name("Email");
	   mobile=By.id("txtPhone");
	   button=By.id("btnPayment");
	   city=By.name("city");
	   state=By.name("state");
	   guest=By.name("persons");
	   cardHolderName=By.id("txtCardholderName");
	   debitCardNumber=By.id("txtDebit");
	   cvv=By.id("txtCvv");
	   expMonth=By.id("txtMonth");
	   expYear=By.id("txtYear");*/
	}
	
	@When("^checking the title of hotel booking$")
	public void checking_the_title_of_hotel_booking() throws Throwable {
	    title= driver.getTitle();
	}

	@Then("^check title is 'Hotel Booking'$")
	public void check_title_is_Hotel_Booking() throws Throwable {
		String expected="Hotel Booking";
		String actual=title;
		assertEquals(expected, actual);
	}

	
	@When("^Enter Submit without entering firstname$")
	public void enter_Submit_without_entering_firstname() throws Throwable {
		hotelbean.clickButton();
		//driver.findElement(button).click();
		Thread.sleep(1000);
	}

	@Then("^get alert with 'Please fill the First Name'$")
	public void get_alert_with_Please_fill_the_First_Name() throws Throwable {
	 String actual=driver.switchTo().alert().getText();
	 String expecetd="Please fill the First Name";
	 assertEquals(expecetd, actual);
	}

	@When("^Enter Submit without entering lastname$")
	public void enter_Submit_without_entering_lastname() throws Throwable {
	   driver.switchTo().alert().dismiss();
	   // driver.findElement(firstName).sendKeys("aaa");
	   
	    hotelbean.setFirstElement("AA");
	   hotelbean.clickButton();
	   Thread.sleep(1000);
	}

	@Then("^get alert with 'Please fill the Last Name'$")
	public void get_alert_with_Please_fill_the_Last_Name() throws Throwable {
		String actual=driver.switchTo().alert().getText();
		String expected="Please fill the Last Name";
		assertEquals(expected, actual);
	}

	@When("^Enter Submit without entering email$")
	public void enter_Submit_without_entering_email() throws Throwable {
	   driver.switchTo().alert().dismiss();
	   //driver.findElement(firstName).sendKeys("aa");
	   hotelbean.setLastName("bbbb");
	   hotelbean.clickButton();
	   //driver.findElement(lastName).sendKeys("bb");
	   //driver.findElement(button).click();
	   Thread.sleep(1000);
	}

	@Then("^get alert with 'Please fill the Email'$")
	public void get_alert_with_Please_fill_the_Email() throws Throwable {
		String actual= driver.switchTo().alert().getText();
		String expected="Please fill the Email";
		assertEquals(expected, actual);
	}

	@When("^Enter Submit with invalid emailid$")
	public void enter_Submit_with_invalid_emailid() throws Throwable {
		driver.switchTo().alert().dismiss();
		//driver.findElement(firstName).sendKeys("aa");
		//driver.findElement(lastName).sendKeys("bb");
		//driver.findElement(email).sendKeys("abc");   
		//driver.findElement(button).click();
		hotelbean.setEmail("AAsa");
		 hotelbean.clickButton();
		Thread.sleep(1000);
	}

	@Then("^get alert with 'Please enter valid Email Id\\.'$")
	public void get_alert_with_Please_enter_valid_Email_Id() throws Throwable {
	   String actual= driver.switchTo().alert().getText();
	   String expected="Please enter valid Email Id.";
	   assertEquals(expected, actual);
	}

	@When("^Enter Submit without entering mobileno$")
	public void enter_Submit_without_entering_mobileno() throws Throwable {
	    driver.switchTo().alert().dismiss();
	    hotelbean.setEmail("john@abc.com");
	    hotelbean.clickButton();
	    //driver.findElement(firstName).sendKeys("aa");
		//driver.findElement(lastName).sendKeys("bb");
	    //driver.findElement(email).clear();
		//driver.findElement(email).sendKeys("abc@gmail.com");
		//driver.findElement(button).click();
		Thread.sleep(1000);
	}

	@Then("^get alert with 'Please fill the Mobile No\\.'$")
	public void get_alert_with_Please_fill_the_Mobile_No() throws Throwable {
		 String actual= driver.switchTo().alert().getText();
		 String expected="Please fill the Mobile No.";
		 assertEquals(expected, actual);
	}

	@When("^Enter Submit with invalid mobileno$")
	public void enter_Submit_with_invalid_mobileno() throws Throwable {
		 	driver.switchTo().alert().dismiss();
		    //driver.findElement(firstName).sendKeys("aa");
			//driver.findElement(lastName).sendKeys("bb");
			//driver.findElement(email).sendKeys("abc@gmail.com");
			//driver.findElement(mobile).sendKeys("987456");
			//driver.findElement(button).click();
			hotelbean.setMobile("789");
			hotelbean.clickButton();
			Thread.sleep(1000);
	}

	@Then("^get alert with 'Please enter valid Contact no\\.'$")
	public void get_alert_with_Please_enter_valid_Contact_no() throws Throwable {
		 String actual= driver.switchTo().alert().getText();
		 String expected="Please enter valid Contact no.";
		 assertEquals(expected,actual);
	}
	
	@When("^Enter submit without entering city$")
	public void enter_submit_without_entering_city() throws Throwable {
		driver.switchTo().alert().dismiss();
		/*driver.findElement(mobile).clear();
		driver.findElement(mobile).sendKeys("7894561234");
	  //  driver.findElement(city).sendKeys("Pune");
	    driver.findElement(button).click();*/
	    hotelbean.setMobile("7894512214");
	    hotelbean.clickButton();
	    Thread.sleep(1000);
	    
	
	}

	@Then("^get alert with 'Please select city'$")
	public void get_alert_with_Please_select_city() throws Throwable {
		 String actual= driver.switchTo().alert().getText();
		 String expected="Please select city";
		 assertEquals(expected,actual);
	}
	@When("^Enter submit without entering state$")
	public void enter_submit_without_entering_state() throws Throwable {
		driver.switchTo().alert().dismiss();
		/*driver.findElement(city).sendKeys("Pune");
		driver.findElement(button).click();*/
		hotelbean.setCity("Chennai");
		hotelbean.clickButton();
		Thread.sleep(1000);
	}

	@Then("^get alert with 'Please select state'$")
	public void get_alert_with_Please_select_state() throws Throwable {
		String actual= driver.switchTo().alert().getText();
		 String expected="Please select state";
		 assertEquals(expected,actual);
	}
	/*@When("^enter submit without wntering guests$")
	public void enter_submit_without_wntering_guests() throws Throwable {
		
		driver.switchTo().alert().dismiss();
		driver.findElement(state).sendKeys("Telangana");
	   driver.findElement(button).click();
	}

	@Then("^get alert 'Please fill the Number of people attending'$")
	public void get_alert_Please_fill_the_Number_of_people_attending() throws Throwable {
		String actual= driver.switchTo().alert().getText();
		 String expected="Please fill the Number of people attending";
		 assertEquals(expected,actual);
		 }*/
	@When("^card holder name is empty$")
	public void card_holder_name_is_empty() throws Throwable {
	   driver.switchTo().alert().dismiss();
	/*   driver.findElement(state).sendKeys("Telangana");
	   driver.findElement(guest).sendKeys("2");
	   driver.findElement(button).click();*/
	   hotelbean.setState("Telangana");
	   hotelbean.setGuest("2");
	   hotelbean.clickButton();
	   Thread.sleep(1000);
	}

	@Then("^get alert 'Please fill the Card holder name'$")
	public void get_alert_Please_fill_the_Card_holder_name() throws Throwable {
		String actual= driver.switchTo().alert().getText();
		 String expected="Please fill the Card holder name";
		 assertEquals(expected,actual);
	}
	
	@When("^debit card no is empty$")
	public void debit_card_no_is_empty() throws Throwable {
		 driver.switchTo().alert().dismiss();
		 hotelbean.setCardHolderName("John");
		 hotelbean.clickButton();
		/* driver.findElement(cardHolderName).sendKeys("John");
		 driver.findElement(button).click();*/
		 Thread.sleep(1000);
	}

	@Then("^get alert 'Please fill the Debit card Number'$")
	public void get_alert_Please_fill_the_Debit_card_Number() throws Throwable {
		 String actual= driver.switchTo().alert().getText();
		 String expected="Please fill the Debit card Number";
		 assertEquals(expected,actual);
	}
	@When("^cvv is empty$")
	public void cvv_is_empty() throws Throwable {
		driver.switchTo().alert().dismiss();
		 hotelbean.setDebitCardNumber("123");
		 hotelbean.clickButton();
		 /*driver.findElement(debitCardNumber).sendKeys("123");
		 driver.findElement(button).click();*/
		 Thread.sleep(1000);
	}

	@Then("^get alert 'Please fill the CVV'$")
	public void get_alert_Please_fill_the_CVV() throws Throwable {
		String actual= driver.switchTo().alert().getText();
		 String expected="Please fill the CVV";
		 assertEquals(expected,actual);
	}

	@When("^expMonth is empty$")
	public void expmonth_is_empty() throws Throwable {
		driver.switchTo().alert().dismiss();
		 hotelbean.setCvv("123");
		 hotelbean.clickButton();
		 /*driver.findElement(cvv).sendKeys("789");
		 driver.findElement(button).click();*/
		 Thread.sleep(1000);
	}

	@Then("^get alert 'Please fill expiration month'$")
	public void get_alert_Please_fill_expiration_month() throws Throwable {
		String actual= driver.switchTo().alert().getText();
		 String expected="Please fill expiration month";
		 assertEquals(expected,actual);
	}

	@When("^expYear is empty$")
	public void expyear_is_empty() throws Throwable {
		driver.switchTo().alert().dismiss();
		hotelbean.setExpMonth("12");
		hotelbean.clickButton();
//		 driver.findElement(expMonth).sendKeys("12");
//		 driver.findElement(button).click();
		 Thread.sleep(1000);
	}

	@Then("^get alert 'Please fill the expiration year'$")
	public void get_alert_Please_fill_the_expiration_year() throws Throwable {
		String actual= driver.switchTo().alert().getText();
		 String expected="Please fill the expiration year";
		 assertEquals(expected,actual);
	}
	
	@When("^everything is entered$")
	public void everything_is_entered() throws Throwable {
		driver.switchTo().alert().dismiss();
		hotelbean.setExpYear("1998");
		hotelbean.clickButton();
		 /*driver.findElement(expYear).sendKeys("1998");
		 driver.findElement(button).click();*/
		 Thread.sleep(1000);
	}

	@Then("^submit$")
	public void submit() throws Throwable {
	    System.out.println("Perfectoo");
	}

}
