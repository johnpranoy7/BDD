package com.beans;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class HotelBooking {
	@FindBy(how=How.ID,id="txtFirstName")
	WebElement firstElement;
	@FindBy(how=How.ID,id="txtLastName")
	WebElement lastName;
	@FindBy(how=How.NAME,name="Email")
	WebElement email;
	@FindBy(how=How.ID,id="txtPhone")
	WebElement mobile;
	@FindBy(how=How.ID,id="btnPayment")
	WebElement button;
	@FindBy(how=How.NAME,name="city")
	WebElement city;
	@FindBy(how=How.NAME,name="state")
	WebElement state;
	@FindBy(how=How.NAME,name="persons")
	WebElement guest;
	@FindBy(how=How.ID,id="txtCardholderName")
	WebElement cardHolderName;
	@FindBy(how=How.ID,id="txtDebit")
	WebElement debitCardNumber;
	@FindBy(how=How.ID,id="txtCvv")
	WebElement cvv;
	@FindBy(how=How.ID,id="txtMonth")
	WebElement expMonth;
	@FindBy(how=How.ID,id="txtYear")
	WebElement expYear;
	
	public void clickButton()
	{
		button.click();
	}

	public void setFirstElement(String firstName) {
		this.firstElement.sendKeys(firstName);
	}

	public void setLastName(String last) {
		this.lastName.sendKeys(last);
	}

	public void setEmail(String mail) {
		this.email.clear();
		this.email.sendKeys(mail);
	}

	public void setMobile(String mob) {
		this.mobile.clear();
		this.mobile.sendKeys(mob);
	}

	public void setCity(String cit) {
		this.city.sendKeys(cit);
	}

	public void setState(String stat) {
		this.state.sendKeys(stat);
	}

	public void setGuest(String gues) {
		this.guest.sendKeys(gues);
	}

	public void setCardHolderName(String cardHolderNam) {
		this.cardHolderName.sendKeys(cardHolderNam);
	}

	public void setDebitCardNumber(String debitCardNumbe) {
		this.debitCardNumber.sendKeys(debitCardNumbe);
	}

	public void setCvv(String cv) {
		this.cvv.sendKeys(cv);
	}

	public void setExpMonth(String expMont) {
		this.expMonth.sendKeys(expMont);
	}

	public void setExpYear(String expYea) {
		this.expYear.sendKeys(expYea);
	}
	
}
